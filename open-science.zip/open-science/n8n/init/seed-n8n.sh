#!/bin/sh
set -eu

# Import any workflows found in /seed/workflows.
# Works with directory exports (multiple .json files) or a single workflows.json.
echo "[n8n-seed] Seeding workflows from /seed/workflows ..."

if [ ! -d /seed/workflows ]; then
  echo "[n8n-seed] No /seed/workflows directory mounted; skipping."
  exit 0
fi

# Create DB directory if missing
mkdir -p /home/node/.n8n

# Import: if a single file exists
if [ -f /seed/workflows/workflows.json ]; then
  n8n import:workflow --input=/seed/workflows/workflows.json || true
else
  # Import all JSONs in directory
  found=0
  for f in /seed/workflows/*.json; do
    if [ -f "$f" ]; then
      found=1
      echo "[n8n-seed] Importing $f"
      n8n import:workflow --input="$f" || true
    fi
  done
  if [ "$found" -eq 0 ]; then
    echo "[n8n-seed] No .json workflow exports found; skipping."
  fi
fi

echo "[n8n-seed] Done."
