import os, csv, json, base64, urllib.request, urllib.error, time, pathlib

elastic_url = os.environ.get("ELASTIC_URL", "http://elasticsearch:9200").rstrip("/")
user = os.environ.get("ELASTIC_USER", "elastic")
password = os.environ.get("ELASTIC_PASSWORD", "")
index = os.environ.get("ELK_INDEX", "cic-dns-2024")
results_index = os.environ.get("LLM_RESULTS_INDEX", "llm-dns-results")

xlsx_path = os.environ.get("ELK_XLSX", "/seed/cic-dns-2024-batch.xlsx")
csv_path = os.environ.get("ELK_CSV", "/seed/cic-dns-2024-batch.csv")

if not password:
    raise SystemExit("ELASTIC_PASSWORD is required (set it in .env).")

auth = base64.b64encode(f"{user}:{password}".encode("utf-8")).decode("ascii")

def req(method, path, body=None, content_type="application/json"):
    url = f"{elastic_url}{path}"
    headers = {"Authorization": f"Basic {auth}"}
    if content_type:
        headers["Content-Type"] = content_type
    data = None if body is None else body.encode("utf-8")
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=60) as resp:
            return resp.status, resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8")

def ensure_index(name: str):
    code, body = req("PUT", f"/{name}", body=json.dumps({
        "settings": {"number_of_shards": 1, "number_of_replicas": 0}
    }))
    if code in (200,201,400):
        return
    print(code, body)
    raise SystemExit(f"Failed to create index {name}")

# Wait for ES
for _ in range(90):
    code, _ = req("GET", "/")
    if code == 200:
        break
    time.sleep(2)
else:
    raise SystemExit("Elasticsearch did not become ready in time.")

# Ensure both indices exist
ensure_index(index)
ensure_index(results_index)

# Prefer CSV if present; otherwise try XLSX -> CSV in memory
rows = []
if os.path.exists(csv_path):
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
elif os.path.exists(xlsx_path):
    import pandas as pd
    df = pd.read_excel(xlsx_path, engine="openpyxl")
    rows = df.astype(str).to_dict(orient="records")
else:
    print(f"[elk-seed] No CSV ({csv_path}) or XLSX ({xlsx_path}) found; skipping ingest.")
    raise SystemExit(0)

# Limit to 1000 docs for artifact-friendly ingest
rows = rows[:1000]
if not rows:
    print("[elk-seed] Seed file empty; nothing to ingest.")
    raise SystemExit(0)

actions = []
for row in rows:
    actions.append(json.dumps({"index": {"_index": index}}))
    actions.append(json.dumps(row))

ndjson = "\n".join(actions) + "\n"
code, body = req("POST", "/_bulk?refresh=true", body=ndjson, content_type="application/x-ndjson")
if code not in (200,201):
    print(code, body)
    raise SystemExit("Bulk ingest failed")

print(f"[elk-seed] Ingested {len(rows)} docs into index '{index}'. Created/verified '{results_index}'.")
