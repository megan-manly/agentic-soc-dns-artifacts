# Pinned Images Report

## Main stack changes
- elasticsearch: docker.elastic.co/elasticsearch/elasticsearch:8.15.2 -> docker.elastic.co/elasticsearch/elasticsearch@sha256:4635ed9a36b5d5f9269a9d1f4d36f6a3774069aba3da95a9ddd68ee04e7c2a56
- kibana: docker.elastic.co/kibana/kibana:8.15.2 -> docker.elastic.co/kibana/kibana@sha256:15eae702bc84cf402fc24a4582d1596b7c61b32bd71801ae0eadc675a147d9ae
- logstash: docker.elastic.co/logstash/logstash:8.15.2 -> docker.elastic.co/logstash/logstash@sha256:fc7cab60292b05bd0a32c8f7020cbdc187bdb0e3efeb511fa82fb1fb2693fe45
- mcp-es: docker.elastic.co/mcp/elasticsearch:latest -> docker.elastic.co/mcp/elasticsearch@sha256:d57ea11dcb3451ca332cb6d3bb8c4bb1ea29f15e498937ad6c2eada9f88eb003
- n8n: n8nio/n8n:latest -> n8nio/n8n@sha256:a9beb0dcaa547f0742a322f497af72127338d6ab8f3697b3be44f8ab737726f2
- n8n-seed: n8nio/n8n:latest -> n8nio/n8n@sha256:a9beb0dcaa547f0742a322f497af72127338d6ab8f3697b3be44f8ab737726f2
- ollama: ollama/ollama:latest -> ollama/ollama@sha256:37ef34d78a6f4563a11cbbb336bbaa75f01eb19671d639973f98baa58f11a5ed
- ollama-seed: ollama/ollama:latest -> ollama/ollama@sha256:37ef34d78a6f4563a11cbbb336bbaa75f01eb19671d639973f98baa58f11a5ed

## OpenCTI overlay pins
- redis: redis:8.2.1 -> redis@sha256:5fa2edb1e408fa8235e6db8fab01d1afaaae96c9403ba67b70feceb8661e8621
- elasticsearch: docker.elastic.co/elasticsearch/elasticsearch:8.19.2 -> docker.elastic.co/elasticsearch/elasticsearch@sha256:21f64facd9a01bedcf1ee190f73246220a540f4a87bfbfa3c4e18d9681becd4d
- minio: minio/minio:RELEASE.2025-06-13T11-33-47Z -> minio/minio@sha256:064117214caceaa8d8a90ef7caa58f2b2aeb316b5156afe9ee8da5b4d83e12c8
- rabbitmq: rabbitmq:4.1-management -> rabbitmq@sha256:34d2a5242059cd570fca68099202cd92161bc576888cda04b67fcdefd7227470
- opencti: opencti/platform:6.7.17 -> opencti/platform@sha256:c39af3e492929a580733d88256b2e6c7f6ddadf8bc3677cc9c92f35836d077f0
- worker: opencti/worker:6.7.17 -> opencti/worker@sha256:114474035591d75b90e8d02b8069bcf493a75778fa6e1427764e99bcd209a124
- connector-export-file-stix: opencti/connector-export-file-stix:6.7.17 -> opencti/connector-export-file-stix@sha256:36db59162100c14bffef6deae3b776e979d490da9f4fc62267618000317cb266
- connector-export-file-csv: opencti/connector-export-file-csv:6.7.17 -> opencti/connector-export-file-csv@sha256:bf91508cc53d8fbbfecf4b4ccd177b232c40f1b80e0805b84d7d255c05e1950b
- connector-export-file-txt: opencti/connector-export-file-txt:6.7.17 -> opencti/connector-export-file-txt@sha256:9a8a56c79ec487fd702781c5e6cc74c2c490840a5fa403e37adf414548039328
- connector-import-file-stix: opencti/connector-import-file-stix:6.7.17 -> opencti/connector-import-file-stix@sha256:f7ec16f331880ea9375556f3db08d8fb51f16049f4e1db6a414a15c3220b3d97
- connector-import-document: opencti/connector-import-document:6.7.17 -> opencti/connector-import-document@sha256:c892784e23ccc6da209bba512cc9a78128d0e9c5ac6b4cf95f0b5794c470bc84
- connector-analysis: opencti/connector-import-document:6.7.17 -> opencti/connector-import-document@sha256:c892784e23ccc6da209bba512cc9a78128d0e9c5ac6b4cf95f0b5794c470bc84
