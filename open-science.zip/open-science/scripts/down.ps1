Param(
  [string]$EnvFile = ".\.env"
)

$ErrorActionPreference = "Stop"

Write-Host "== Tearing down main stack =="
docker compose --env-file $EnvFile -f .\docker-compose.yml down

Write-Host "== Tearing down OpenCTI stack =="
docker compose --env-file $EnvFile -f .\opencti\docker-compose.yml -f .\opencti\docker-compose.override.yml down
