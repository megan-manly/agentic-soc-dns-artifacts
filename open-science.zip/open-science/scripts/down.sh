#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Repo root = parent of scripts/
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ROOT_DIR  = Resolve-Path (Join-Path $ScriptDir "..") | Select-Object -ExpandProperty Path

# Match bash behavior:
# ENV_FILE defaults to "$ROOT_DIR/.env" unless overridden by environment variable ENV_FILE
$ENV_FILE = if ($env:ENV_FILE -and $env:ENV_FILE.Trim().Length -gt 0) {
  $env:ENV_FILE
} else {
  Join-Path $ROOT_DIR ".env"
}

function Exec([string]$cmd, [string[]]$args) {
  $p = Start-Process -FilePath $cmd -ArgumentList $args -NoNewWindow -Wait -PassThru
  if ($p.ExitCode -ne 0) { throw "Command failed: $cmd $($args -join ' ') (exit $($p.ExitCode))" }
}

Write-Host "== Tearing down main stack =="

Exec "docker" @(
  "compose",
  "--env-file", $ENV_FILE,
  "-f", (Join-Path $ROOT_DIR "docker-compose.yml"),
  "down"
)

Write-Host "== Tearing down OpenCTI stack =="

Exec "docker" @(
  "compose",
  "--env-file", $ENV_FILE,
  "-f", (Join-Path $ROOT_DIR "opencti\docker-compose.yml"),
  "-f", (Join-Path $ROOT_DIR "opencti\docker-compose.override.yml"),
  "down"
)
