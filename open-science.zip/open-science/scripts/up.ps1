#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Host "=== Open Science Artifact Bring-Up (Windows / PowerShell) ==="

# Repo root = parent of scripts/
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ROOT_DIR  = Resolve-Path (Join-Path $ScriptDir "..") | Select-Object -ExpandProperty Path

# ENV_FILE can be overridden: $env:ENV_FILE="C:\path\.env"
$ENV_FILE = if ($env:ENV_FILE -and $env:ENV_FILE.Trim().Length -gt 0) { $env:ENV_FILE } else { Join-Path $ROOT_DIR ".env" }

# Compose profiles can be provided, but NOTE:
# Your docker-compose.yml always includes the CPU 'ollama' service.
# So for GPU mode we explicitly start 'ollama-gpu' and do NOT start 'ollama' to avoid port 11434 conflicts.
$COMPOSE_PROFILES = if ($env:COMPOSE_PROFILES) { $env:COMPOSE_PROFILES } else { "" }

function ExecDocker {
  param([Parameter(Mandatory=$true)][string[]]$Args)

  & docker @Args
  if ($LASTEXITCODE -ne 0) {
    throw "Docker command failed: docker $($Args -join ' ') (exit $LASTEXITCODE)"
  }
}

function Ensure-Docker {
  try { ExecDocker @("version") } catch { throw "Docker is not available. Start Docker Desktop and retry." }
  try { ExecDocker @("compose","version") } catch { throw "Docker Compose v2 not available (docker compose). Update Docker Desktop." }
}

function Print-ProfileInfo {
  if ($COMPOSE_PROFILES.Trim().Length -gt 0) {
    Write-Host "[Info] COMPOSE_PROFILES=$COMPOSE_PROFILES"
  } else {
    Write-Host "[Info] COMPOSE_PROFILES not set (default CPU mode)."
    Write-Host "       To enable GPU: `$env:COMPOSE_PROFILES='gpu'; .\scripts\up.ps1"
  }
}

function Has-Profile([string]$name) {
  $p = $COMPOSE_PROFILES
  if (-not $p -or $p.Trim().Length -eq 0) { return $false }
  $profiles = $p -split '[,\s]+' | Where-Object { $_ -and $_.Trim().Length -gt 0 }
  return ($profiles | Where-Object { $_ -ieq $name } | Select-Object -First 1) -ne $null
}

function Get-ComposeProfileArgs {
  $args = @()
  $p = $COMPOSE_PROFILES
  if ($p -and $p.Trim().Length -gt 0) {
    $profiles = $p -split '[,\s]+' | Where-Object { $_ -and $_.Trim().Length -gt 0 }
    foreach ($prof in $profiles) {
      $args += @("--profile", $prof)
    }
  }
  return $args
}

function ComposeMain {
  param([Parameter(Mandatory=$true)][string[]]$ComposeArgs)

  $base = @("compose") + (Get-ComposeProfileArgs) + @(
    "--env-file", $ENV_FILE,
    "-f", (Join-Path $ROOT_DIR "docker-compose.yml")
  )
  ExecDocker ($base + $ComposeArgs)
}

function ComposeOpenCti {
  param([Parameter(Mandatory=$true)][string[]]$ComposeArgs)

  $base = @("compose") + (Get-ComposeProfileArgs) + @(
    "--env-file",$ENV_FILE,
    "-f",(Join-Path $ROOT_DIR "opencti\docker-compose.yml"),
    "-f",(Join-Path $ROOT_DIR "opencti\docker-compose.override.yml"),
    "-f",(Join-Path $ROOT_DIR "opencti\docker-compose.pins.yml"),
    "-f",(Join-Path $ROOT_DIR "opencti\docker-compose.exclude.yml")
  )
  ExecDocker ($base + $ComposeArgs)
}

function Ensure-AiNet {
  Write-Host "[1/9] Ensuring Docker network ai-net exists..."
  & docker network inspect ai-net *> $null
  if ($LASTEXITCODE -ne 0) {
    ExecDocker @("network","create","ai-net")
  }
}

function Ensure-EnvFile {
  if (-not (Test-Path -LiteralPath $ENV_FILE)) {
    $example = Join-Path $ROOT_DIR ".env.example"
    if (Test-Path -LiteralPath $example) {
      Copy-Item -LiteralPath $example -Destination $ENV_FILE -Force
      Write-Host "Created $ENV_FILE from .env.example"
    } else {
      throw "Missing $ENV_FILE and .env.example"
    }
  }
}

function Read-EnvLines {
  if (-not (Test-Path -LiteralPath $ENV_FILE)) { return @() }
  return Get-Content -LiteralPath $ENV_FILE -ErrorAction Stop
}

function Get-EnvValue([string]$key) {
  $lines = Read-EnvLines
  foreach ($line in $lines) {
    if ($line -match "^\s*$([Regex]::Escape($key))\s*=") {
      $idx = $line.IndexOf("=")
      if ($idx -ge 0) { return $line.Substring($idx + 1) }
    }
  }
  return ""
}

function Set-EnvValue([string]$key, [string]$value) {
  $lines = Read-EnvLines
  $found = $false
  for ($i=0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match "^\s*$([Regex]::Escape($key))\s*=") {
      $lines[$i] = "$key=$value"
      $found = $true
      break
    }
  }
  if (-not $found) {
    $lines += ""
    $lines += "$key=$value"
  }
  Set-Content -LiteralPath $ENV_FILE -Value $lines -Encoding UTF8
}

function Ensure-LogstashFiles {
  $cfgDir      = Join-Path $ROOT_DIR "logstash\config"
  $cfgFile     = Join-Path $cfgDir  "logstash.yml"
  $pipelineDir = Join-Path $ROOT_DIR "logstash\pipeline"

  New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null
  New-Item -ItemType Directory -Path $pipelineDir -Force | Out-Null

  if (Test-Path -LiteralPath $cfgFile -PathType Container) {
    Write-Host "[Logstash] WARNING: $cfgFile is a directory; replacing with a file."
    Remove-Item -LiteralPath $cfgFile -Recurse -Force
  }

  if (-not (Test-Path -LiteralPath $cfgFile -PathType Leaf)) {
    Write-Host "[Logstash] Creating missing $cfgFile"
@"
api.http.host: "0.0.0.0"
path.config: /usr/share/logstash/pipeline/*.conf
pipeline.ordered: auto
log.level: info
"@ | Set-Content -LiteralPath $cfgFile -Encoding UTF8
  }
}

function Is-UUID([string]$s) {
  return $s -match '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
}

function Ensure-OpenCTIAdminEmail {
  $email = (Get-EnvValue "OPENCTI_ADMIN_EMAIL").Trim()
  if ($email.Length -eq 0 -or ($email -notmatch '^.+@.+\..+$')) {
    $defaultEmail = "reviewer@local.test"
    Write-Host "[OpenCTI] OPENCTI_ADMIN_EMAIL missing/invalid; setting to $defaultEmail"
    Set-EnvValue "OPENCTI_ADMIN_EMAIL" $defaultEmail
  }
}

function Ensure-OpenCTIAdminToken {
  Write-Host "[OpenCTI] Ensuring OPENCTI_ADMIN_TOKEN is a valid UUID..."
  $token = (Get-EnvValue "OPENCTI_ADMIN_TOKEN").Trim()
  if (-not (Is-UUID $token)) {
    $newToken = ([guid]::NewGuid().ToString().ToLowerInvariant())
    Write-Host "[OpenCTI] OPENCTI_ADMIN_TOKEN missing/invalid; generating: $newToken"
    Set-EnvValue "OPENCTI_ADMIN_TOKEN" $newToken
  }
}

function New-UrlSafeToken([int]$bytes = 48) {
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  $data = New-Object byte[] ($bytes)
  $rng.GetBytes($data)
  $b64 = [Convert]::ToBase64String($data)
  $b64 = $b64.TrimEnd('=').Replace('+','-').Replace('/','_')
  return $b64
}

function Ensure-KibanaEncryptionKeys {
  $k1 = (Get-EnvValue "KIBANA_ENCRYPTION_KEY").Trim()
  $k2 = (Get-EnvValue "KIBANA_REPORTING_KEY").Trim()
  $k3 = (Get-EnvValue "KIBANA_SECURITY_KEY").Trim()

  if ($k1.Length -eq 0) { Write-Host "[Kibana] Setting KIBANA_ENCRYPTION_KEY"; Set-EnvValue "KIBANA_ENCRYPTION_KEY" (New-UrlSafeToken 48) }
  if ($k2.Length -eq 0) { Write-Host "[Kibana] Setting KIBANA_REPORTING_KEY"; Set-EnvValue "KIBANA_REPORTING_KEY" (New-UrlSafeToken 48) }
  if ($k3.Length -eq 0) { Write-Host "[Kibana] Setting KIBANA_SECURITY_KEY"; Set-EnvValue "KIBANA_SECURITY_KEY" (New-UrlSafeToken 48) }
}

function Wait-EsOk([int]$seconds = 240) {
  $elasticPass = (Get-EnvValue "ELASTIC_PASSWORD").Trim()
  if ($elasticPass.Length -eq 0) { throw "ELASTIC_PASSWORD must be set in $ENV_FILE" }

  $deadline = (Get-Date).AddSeconds($seconds)
  while ((Get-Date) -lt $deadline) {
    try {
      $pair = "elastic:$elasticPass"
      $basic = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
      $headers = @{ Authorization = "Basic $basic" }
      $null = Invoke-RestMethod -Uri "http://localhost:9200/_cluster/health" -Headers $headers -Method Get -TimeoutSec 5
      return
    } catch {
      Start-Sleep -Seconds 2
    }
  }
  throw "Timed out waiting for Elasticsearch auth endpoint (http://localhost:9200/_cluster/health)"
}

function Wait-EsSecurityReady([int]$seconds = 240) {
  $elasticPass = (Get-EnvValue "ELASTIC_PASSWORD").Trim()
  if ($elasticPass.Length -eq 0) { throw "ELASTIC_PASSWORD must be set in $ENV_FILE" }

  $pair  = "elastic:$elasticPass"
  $basic = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
  $headers = @{ Authorization = "Basic $basic" }

  $deadline = (Get-Date).AddSeconds($seconds)
  while ((Get-Date) -lt $deadline) {
    try {
      $null = Invoke-RestMethod -Uri "http://localhost:9200/_security/_authenticate" -Headers $headers -Method Get -TimeoutSec 5
      return
    } catch {
      Start-Sleep -Seconds 2
    }
  }
  throw "Timed out waiting for Elasticsearch security subsystem readiness."
}

function Pull-WithRetry([string]$img, [int]$tries = 6, [int]$delay = 5) {
  for ($i=1; $i -le $tries; $i++) {
    Write-Host "  - Pulling $img (attempt $i/$tries)..."
    & docker pull $img | Out-Null
    if ($LASTEXITCODE -eq 0) { Write-Host "    Pulled: $img"; return }
    Write-Host "    Pull failed for $img; sleeping ${delay}s before retry..."
    Start-Sleep -Seconds $delay
    $delay = [Math]::Min($delay * 2, 120)
  }
  throw "Failed to pull $img after $tries attempts."
}

function List-ImagesFromCompose([string[]]$files) {
  $set = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($f in $files) {
    if (-not (Test-Path -LiteralPath $f)) { continue }
    $lines = Get-Content -LiteralPath $f -ErrorAction Stop
    foreach ($ln in $lines) {
      if ($ln -match '^\s*image:\s*(.+?)\s*$') {
        $img = $Matches[1].Trim().Trim('"')
        if ($img.Length -gt 0) { $null = $set.Add($img) }
      }
    }
  }
  return $set
}

function Ensure-KibanaSystemPassword {
  $elasticPass = (Get-EnvValue "ELASTIC_PASSWORD").Trim()
  if ($elasticPass.Length -eq 0) { throw "ELASTIC_PASSWORD must be set in $ENV_FILE (needed to set kibana_system password)" }

  $kibanaPass = (Get-EnvValue "KIBANA_SYSTEM_PASSWORD").Trim()
  if ($kibanaPass.Length -eq 0) {
    Write-Host "[ELK] KIBANA_SYSTEM_PASSWORD not set; leaving kibana_system unchanged."
    Write-Host "      (If you do fresh rebuilds with -v, set KIBANA_SYSTEM_PASSWORD in .env to avoid auth drift.)"
    return
  }

  Write-Host "[ELK] Syncing kibana_system password from .env into Elasticsearch..."
  $pair = "elastic:$elasticPass"
  $basic = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
  $headers = @{
    Authorization  = "Basic $basic"
    "Content-Type" = "application/json"
  }
  $body = @{ password = $kibanaPass } | ConvertTo-Json -Compress

  $deadline = (Get-Date).AddSeconds(180)
  while ((Get-Date) -lt $deadline) {
    try {
      $null = Invoke-RestMethod -Uri "http://localhost:9200/_security/user/kibana_system/_password" `
        -Headers $headers -Method Post -Body $body -TimeoutSec 15
      return
    } catch {
      $msg = $_.Exception.Message
      if ($msg -match "503" -or $msg -match "Cluster state has not been recovered yet") {
        Start-Sleep -Seconds 3
        continue
      }
      throw
    }
  }
  throw "Timed out syncing kibana_system password (Elasticsearch not yet ready for security writes)."
}

function Get-EsContainerName {
  $byName = (& docker ps --format "{{.Names}}" 2>$null | Where-Object { $_ -eq "elasticsearch" } | Select-Object -First 1)
  if ($byName) { return $byName }

  $any = (& docker ps --format "{{.Names}}" 2>$null | Where-Object { $_ -match "elasticsearch" } | Select-Object -First 1)
  if ($any) { return $any }

  return ""
}

function Elk-ApiKeyHttpCode([string]$key) {
  $es = Get-EsContainerName
  if (-not $es) { return "000" }

  try {
    $out = & docker exec -i $es curl `
      -s -o /dev/null -w "%{http_code}" `
      -H ("Authorization: ApiKey {0}" -f $key) `
      "http://localhost:9200/_security/_authenticate" 2>$null

    if ($LASTEXITCODE -ne 0 -or -not $out) { return "000" }
    return ($out.ToString().Trim())
  } catch {
    return "000"
  }
}

function Recreate-McpEs {
  ComposeMain @("up","-d","--force-recreate","--no-deps","mcp-es")
}

function Ensure-ValidElkApiKey {
  $apiKey = (Get-EnvValue "ELK_ES_API_KEY")
  $apiKey = if ($apiKey) { $apiKey } else { "" }

  if ($apiKey.Trim().Length -gt 0) {
    Write-Host "[7/9] Validating ELK_ES_API_KEY against Elasticsearch (Docker-only)..."
    $code = Elk-ApiKeyHttpCode $apiKey
    if ($code -eq "200") {
      Write-Host "[MCP] ELK_ES_API_KEY is valid."
      Write-Host "[MCP] Recreating mcp-es to ensure it is using the current env value..."
      Recreate-McpEs
      return
    }
    Write-Host "[MCP] ELK_ES_API_KEY is not valid for this Elasticsearch (HTTP $code). Will generate a new key."
  } else {
    Write-Host "[7/9] ELK_ES_API_KEY missing; will generate one for MCP..."
  }

  $elasticPass = (Get-EnvValue "ELASTIC_PASSWORD").Trim()
  if ($elasticPass.Length -eq 0) { throw "ELASTIC_PASSWORD must be set in $ENV_FILE" }

  try {
    $pair = "elastic:$elasticPass"
    $basic = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
    $headers = @{ Authorization = "Basic $basic" }
    $null = Invoke-RestMethod -Uri "http://localhost:9200/_security/_authenticate" -Headers $headers -Method Get -TimeoutSec 10
  } catch {
    throw "elastic superuser authentication failed. Check ELASTIC_PASSWORD."
  }

  $ts = Get-Date -Format "yyyyMMddHHmmss"
  $payload = @{
    name = "open-science-mcp-$ts"
    role_descriptors = @{
      mcp_reader = @{
        cluster = @("monitor")
        index = @(
          @{
            names = @("cic-dns-2024","llm-dns-results")
            privileges = @("read","view_index_metadata","create_index","write")
          }
        )
      }
    }
  } | ConvertTo-Json -Depth 10 -Compress

  $basic2 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("elastic:$elasticPass"))
  $headers2 = @{
    Authorization  = "Basic $basic2"
    "Content-Type" = "application/json"
  }

  $resp = Invoke-RestMethod -Uri "http://localhost:9200/_security/api_key" -Headers $headers2 -Method Post -Body $payload -TimeoutSec 15
  $encoded = ($resp.encoded | ForEach-Object { "$_" }).Trim()
  if (-not $encoded) { throw "Failed to create API key (.encoded missing)." }

  Set-EnvValue "ELK_ES_API_KEY" $encoded

  $code2 = Elk-ApiKeyHttpCode $encoded
  if ($code2 -ne "200") { throw "Newly-created ELK_ES_API_KEY still fails auth (HTTP $code2). Check ES security state." }

  Write-Host "[MCP] Wrote ELK_ES_API_KEY into $ENV_FILE"
  Write-Host "[MCP] Recreating mcp-es to pick up the new API key..."
  Recreate-McpEs
}

function Try-OpenCtiUp {
  try {
    ComposeOpenCti @("up","-d")
    return $true
  } catch {
    return $false
  }
}

function OpenCtiDownVolumes {
  ComposeOpenCti @("down","-v")
}

function Tail-Logs([string]$container, [int]$lines = 200) {
  try { return (& docker logs --tail $lines $container 2>&1 | Out-String) } catch { return "" }
}

function OpenCtiRabbitInvalidCredsDetected {
  $rb = Tail-Logs "opencti-rabbitmq-1" 200
  if ($rb -match "PLAIN login refused: user '.+' - invalid credentials") { return $true }
  return $false
}

function Ensure-OpenCtiUpWithAutoRecovery {
  Write-Host "[6/9] Bringing up OpenCTI (base + override + pins + exclude)..."

  if (Try-OpenCtiUp) { return }

  Write-Host "[OpenCTI] Compose up failed. Checking for RabbitMQ credential drift..."

  if (OpenCtiRabbitInvalidCredsDetected) {
    Write-Host "[OpenCTI] Detected RabbitMQ invalid credentials (persistent volume drift)."
    Write-Host "[OpenCTI] Resetting OpenCTI volumes (down -v) and retrying once..."
    OpenCtiDownVolumes

    if (Try-OpenCtiUp) {
      Write-Host "[OpenCTI] OpenCTI started successfully after volume reset."
      return
    }
    throw "OpenCTI still failed after credential-drift recovery. Check logs: docker logs opencti-opencti-1 and opencti-rabbitmq-1"
  }

  throw "OpenCTI failed to start (not a RabbitMQ invalid-credentials case). Check logs: docker logs opencti-opencti-1"
}

function Get-MainServicesToUp {
  # From your docker-compose.yml:
  #   elasticsearch, kibana, logstash, mcp-es, n8n-seed, n8n, ollama-seed, ollama, ollama-gpu
  # GPU mode: start ollama-gpu ONLY (do NOT start ollama) to avoid 11434 bind conflict.
  if (Has-Profile "gpu") {
    return @("kibana","logstash","mcp-es","n8n-seed","n8n","ollama-seed","ollama-gpu")
  } else {
    return @("kibana","logstash","mcp-es","n8n-seed","n8n","ollama-seed","ollama")
  }
}

# ------------------ MAIN ------------------
Ensure-Docker
Print-ProfileInfo
Ensure-AiNet
Ensure-EnvFile
Ensure-OpenCTIAdminEmail
Ensure-OpenCTIAdminToken
Ensure-KibanaEncryptionKeys
Ensure-LogstashFiles

Write-Host "[2/9] Pre-pulling Docker images (sequential with retries)..."

$OPENCTI_FILES = @(
  (Join-Path $ROOT_DIR "opencti\docker-compose.yml"),
  (Join-Path $ROOT_DIR "opencti\docker-compose.override.yml"),
  (Join-Path $ROOT_DIR "opencti\docker-compose.pins.yml"),
  (Join-Path $ROOT_DIR "opencti\docker-compose.exclude.yml")
)

$MAIN_FILES = @(
  (Join-Path $ROOT_DIR "docker-compose.yml")
)

$allFiles = @()
$allFiles += $OPENCTI_FILES
$allFiles += $MAIN_FILES

$images = List-ImagesFromCompose $allFiles
foreach ($img in $images) {
  if ($img -and $img.Trim().Length -gt 0) { Pull-WithRetry $img }
}

Write-Host "[3/9] Bringing up Elasticsearch first (so we can sync kibana_system creds before Kibana starts)..."
ComposeMain @("up","-d","elasticsearch")

Write-Host "[4/9] Waiting for Elasticsearch..."
Wait-EsOk 240

Write-Host "[4b] Waiting for Elasticsearch security subsystem readiness..."
Wait-EsSecurityReady 240

Ensure-KibanaSystemPassword

Write-Host "[5/9] Bringing up the rest of the main stack (Kibana + Logstash + MCP + n8n + Ollama)..."
$svc = Get-MainServicesToUp
ComposeMain ( @("up","-d") + $svc )

Ensure-OpenCtiUpWithAutoRecovery
Ensure-ValidElkApiKey

Write-Host "[8/9] Kibana quick status..."
try {
  $null = Invoke-WebRequest -Uri "http://localhost:5601/api/status" -UseBasicParsing -TimeoutSec 5
  Write-Host "  Kibana status endpoint reachable."
} catch {
  Write-Host "  Kibana status not reachable yet. Check logs: docker logs -f kibana"
}

Write-Host "[9/9] Done."
Write-Host ""
Write-Host "Services:"
Write-Host "  ELK Elasticsearch: http://localhost:9200"
Write-Host "  Kibana:            http://localhost:5601"
Write-Host "  n8n:               http://localhost:5678"
Write-Host "  Ollama:            http://localhost:11434"
Write-Host "  OpenCTI:           http://localhost:8080"
