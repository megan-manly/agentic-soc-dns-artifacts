#!/usr/bin/env bash
set -euo pipefail

echo "=== Open Science Artifact Bring-Up (macOS/Linux) ==="

# Repo root = parent of scripts/
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ENV_FILE:-$ROOT_DIR/.env}"

# Compose profiles (e.g., COMPOSE_PROFILES=gpu ./scripts/up.sh)
COMPOSE_PROFILES="${COMPOSE_PROFILES:-}"

# Generate ELK API key if missing
# ---- MCP/ES API key management ----
# API keys don't auto-rotate, but they become invalid if ES security state is reset (e.g., volume wipe).
# Also, container env vars do not update on "restart" — we must recreate mcp-es when the key changes.
ensure_curlimages_curl() {
  docker image inspect curlimages/curl:8.6.0 >/dev/null 2>&1 || docker pull curlimages/curl:8.6.0 >/dev/null
}

elk_api_key_http_code() {
  local key="$1"
  ensure_curlimages_curl
  docker run --rm --network ai-net curlimages/curl:8.6.0 \
    -sS -o /dev/null -w "%{http_code}" \
    -H "Authorization: ApiKey ${key}" \
    http://elasticsearch:9200/_security/_authenticate 2>/dev/null || echo "000"
}

recreate_mcp_es() {
  docker compose --env-file "$ENV_FILE" -f "$ROOT_DIR/docker-compose.yml" up -d --force-recreate --no-deps mcp-es >/dev/null
}

ensure_valid_elk_api_key() {
  local api_key elastic_pass code encoded

  api_key="$(get_env_value "ELK_ES_API_KEY")"
  api_key="${api_key:-}"

  # If present, validate against the *main* Elasticsearch service on ai-net
  if [[ -n "${api_key//[[:space:]]/}" ]]; then
    echo "[7/9] Validating ELK_ES_API_KEY against Elasticsearch..."
    code="$(elk_api_key_http_code "$api_key")"
    if [[ "$code" == "200" ]]; then
      echo "[MCP] ELK_ES_API_KEY is valid."
      echo "[MCP] Recreating mcp-es to ensure it is using the current env value..."
      recreate_mcp_es
      return 0
    fi
    echo "[MCP] ELK_ES_API_KEY is not valid for this Elasticsearch (HTTP $code). Will generate a new key."
  else
    echo "[7/9] ELK_ES_API_KEY missing; will generate one for MCP..."
  fi

  elastic_pass="$(get_env_value "ELASTIC_PASSWORD")"
  if [[ -z "${elastic_pass//[[:space:]]/}" ]]; then
    echo "ERROR: ELASTIC_PASSWORD must be set in $ENV_FILE" >&2
    exit 1
  fi

  # Auth check before creating the API key
  if ! curl -fsS -u "elastic:${elastic_pass}" "http://localhost:9200/_security/_authenticate" >/dev/null; then
    echo "ERROR: elastic superuser authentication failed. Check ELASTIC_PASSWORD." >&2
    exit 1
  fi

  # Create API key and extract .encoded
  encoded="$(
    curl -fsS -u "elastic:${elastic_pass}" \
      -H "Content-Type: application/json" \
      -d "{\"name\":\"open-science-mcp-$(date +%Y%m%d%H%M%S)\",\"role_descriptors\":{\"mcp_reader\":{\"cluster\":[\"monitor\"],\"index\":[{\"names\":[\"cic-dns-2024\",\"llm-dns-results\"],\"privileges\":[\"read\",\"view_index_metadata\",\"create_index\",\"write\"]}]}}}" \
      "http://localhost:9200/_security/api_key" \
    | python3 -c 'import sys, json; print(json.load(sys.stdin).get("encoded",""))'
  )"

  if [[ -z "${encoded//[[:space:]]/}" ]]; then
    echo "ERROR: Failed to create API key (.encoded missing)." >&2
    exit 1
  fi

  set_env_value "ELK_ES_API_KEY" "$encoded"

  # Verify the new key works before recreating MCP (catches whitespace / parsing issues)
  code="$(elk_api_key_http_code "$encoded")"
  if [[ "$code" != "200" ]]; then
    echo "ERROR: Newly-created ELK_ES_API_KEY still fails auth (HTTP $code). Check ES security state." >&2
    exit 1
  fi

  echo "[MCP] Wrote ELK_ES_API_KEY into $ENV_FILE"
  echo "[MCP] Recreating mcp-es to pick up the new API key..."
  recreate_mcp_es
}

print_profile_info() {
  local os
  os="$(uname -s 2>/dev/null || true)"

  if [[ -n "${COMPOSE_PROFILES//[[:space:]]/}" ]]; then
    echo "[Info] COMPOSE_PROFILES=${COMPOSE_PROFILES}"
  else
    echo "[Info] COMPOSE_PROFILES not set (default CPU mode)."
    echo "       To enable GPU on Linux+NVIDIA: COMPOSE_PROFILES=gpu ./scripts/up.sh"
  fi

  if [[ "$os" == "Darwin" ]] && [[ "${COMPOSE_PROFILES}" == *gpu* ]]; then
    echo "[Warn] macOS detected and COMPOSE_PROFILES includes 'gpu'."
    echo "       NVIDIA GPU passthrough is not supported in Docker Desktop on macOS."
    echo "       Run without gpu profile: ./scripts/up.sh"
  fi
}

ensure_ai_net() {
  echo "[1/9] Ensuring Docker network ai-net exists..."
  docker network inspect ai-net >/dev/null 2>&1 || docker network create ai-net >/dev/null
}

ensure_env_file() {
  if [[ ! -f "$ENV_FILE" ]]; then
    if [[ -f "$ROOT_DIR/.env.example" ]]; then
      cp "$ROOT_DIR/.env.example" "$ENV_FILE"
      echo "Created $ENV_FILE from .env.example"
    else
      echo "ERROR: Missing $ENV_FILE and .env.example" >&2
      exit 1
    fi
  fi
}

get_env_value() {
  local key="$1"
  awk -F= -v k="$key" 'BEGIN{v=""} $1==k{v=$0; sub(/^[^=]*=/,"",v); print v; exit}' "$ENV_FILE" 2>/dev/null || true
}

set_env_value() {
  local key="$1"
  local value="$2"

  if grep -qE "^${key}=" "$ENV_FILE" 2>/dev/null; then
    # portable in-place sed (macOS needs -i '', linux uses -i)
    if [[ "$(uname -s 2>/dev/null || true)" == "Darwin" ]]; then
      sed -i '' -E "s#^${key}=.*#${key}=${value}#g" "$ENV_FILE"
    else
      sed -i -E "s#^${key}=.*#${key}=${value}#g" "$ENV_FILE"
    fi
  else
    printf "\n%s=%s\n" "$key" "$value" >> "$ENV_FILE"
  fi
}

wait_es_ok() {
  local seconds="${1:-240}"
  local end=$((SECONDS + seconds))

  local elastic_pass
  elastic_pass="$(get_env_value "ELASTIC_PASSWORD")"
  if [[ -z "${elastic_pass//[[:space:]]/}" ]]; then
    echo "ERROR: ELASTIC_PASSWORD must be set in $ENV_FILE" >&2
    exit 1
  fi

  while (( SECONDS < end )); do
    if curl -fsS -u "elastic:${elastic_pass}" "http://localhost:9200/_cluster/health" >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done

  echo "ERROR: Timed out waiting for Elasticsearch auth endpoint (http://localhost:9200/_cluster/health)" >&2
  exit 1
}

pull_with_retry() {
  local img="$1"
  local tries="${2:-6}"
  local delay="${3:-5}"

  for ((i=1; i<=tries; i++)); do
    echo "  - Pulling ${img} (attempt ${i}/${tries})..."
    if docker pull "$img" >/dev/null; then
      echo "    Pulled: ${img}"
      return 0
    fi
    echo "    Pull failed for ${img}; sleeping ${delay}s before retry..."
    sleep "$delay"
    delay=$((delay * 2))
  done

  echo "ERROR: Failed to pull ${img} after ${tries} attempts." >&2
  exit 1
}

list_images_from_compose() {
  local files=("$@")
  local imgs=""
  for f in "${files[@]}"; do
    [[ -f "$f" ]] || continue
    imgs+=$'\n'"$(grep -E '^[[:space:]]*image:[[:space:]]*' "$f" \
      | sed -E 's/^[[:space:]]*image:[[:space:]]*//; s/"//g; s/[[:space:]]+$//' \
      | sed '/^$/d')"
  done
  printf "%s\n" "$imgs" | sed '/^$/d' | awk '!seen[$0]++'
}

ensure_logstash_files() {
  local cfg_dir="$ROOT_DIR/logstash/config"
  local cfg_file="$cfg_dir/logstash.yml"
  local pipeline_dir="$ROOT_DIR/logstash/pipeline"

  mkdir -p "$cfg_dir" "$pipeline_dir"

  if [[ -d "$cfg_file" ]]; then
    echo "[Logstash] WARNING: $cfg_file is a directory; replacing with a file."
    rm -rf "$cfg_file"
  fi

  if [[ ! -f "$cfg_file" ]]; then
    echo "[Logstash] Creating missing $cfg_file"
    cat > "$cfg_file" <<'YML'
api.http.host: "0.0.0.0"
path.config: /usr/share/logstash/pipeline/*.conf
pipeline.ordered: auto
log.level: info
YML
  fi
}

is_uuid() {
  [[ "${1:-}" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]
}

ensure_opencti_admin_email() {
  local email
  email="$(get_env_value "OPENCTI_ADMIN_EMAIL")"
  email="${email:-}"

  if [[ -z "${email//[[:space:]]/}" ]] || [[ ! "$email" =~ ^.+@.+\..+$ ]]; then
    local default_email="reviewer@local.test"
    echo "[OpenCTI] OPENCTI_ADMIN_EMAIL missing/invalid; setting to ${default_email}"
    set_env_value "OPENCTI_ADMIN_EMAIL" "$default_email"
  fi
}

ensure_opencti_admin_token() {
  echo "[OpenCTI] Ensuring OPENCTI_ADMIN_TOKEN is a valid UUID..."
  local token
  token="$(get_env_value "OPENCTI_ADMIN_TOKEN")"
  token="${token:-}"

  if ! is_uuid "$token"; then
    local new_token
    new_token="$(uuidgen | tr '[:upper:]' '[:lower:]')"
    echo "[OpenCTI] OPENCTI_ADMIN_TOKEN missing/invalid; generating: ${new_token}"
    set_env_value "OPENCTI_ADMIN_TOKEN" "$new_token"
  fi
}

# --- Kibana encryption keys: prevent "APIs are disabled" + random keys on restart ---
ensure_kibana_encryption_keys() {
  # Use 32+ chars; urlsafe tokens are fine.
  local k1 k2 k3
  k1="$(get_env_value "KIBANA_ENCRYPTION_KEY")"
  k2="$(get_env_value "KIBANA_REPORTING_KEY")"
  k3="$(get_env_value "KIBANA_SECURITY_KEY")"

  if [[ -z "${k1//[[:space:]]/}" ]]; then
    k1="$(python3 - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
    echo "[Kibana] Setting KIBANA_ENCRYPTION_KEY"
    set_env_value "KIBANA_ENCRYPTION_KEY" "$k1"
  fi

  if [[ -z "${k2//[[:space:]]/}" ]]; then
    k2="$(python3 - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
    echo "[Kibana] Setting KIBANA_REPORTING_KEY"
    set_env_value "KIBANA_REPORTING_KEY" "$k2"
  fi

  if [[ -z "${k3//[[:space:]]/}" ]]; then
    k3="$(python3 - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
    echo "[Kibana] Setting KIBANA_SECURITY_KEY"
    set_env_value "KIBANA_SECURITY_KEY" "$k3"
  fi
}

# --- Critical: ensure kibana_system password in ES matches .env BEFORE Kibana starts ---
ensure_kibana_system_password() {
  local elastic_pass kibana_pass

  elastic_pass="$(get_env_value "ELASTIC_PASSWORD")"
  if [[ -z "${elastic_pass//[[:space:]]/}" ]]; then
    echo "ERROR: ELASTIC_PASSWORD must be set in $ENV_FILE (needed to set kibana_system password)" >&2
    exit 1
  fi

  kibana_pass="$(get_env_value "KIBANA_SYSTEM_PASSWORD")"
  kibana_pass="${kibana_pass:-}"

  if [[ -z "${kibana_pass//[[:space:]]/}" ]]; then
    echo "[ELK] KIBANA_SYSTEM_PASSWORD not set; leaving kibana_system unchanged."
    echo "      (If you do fresh rebuilds with -v, set KIBANA_SYSTEM_PASSWORD in .env to avoid auth drift.)"
    return 0
  fi

  echo "[ELK] Syncing kibana_system password from .env into Elasticsearch..."
  curl -fsS -u "elastic:${elastic_pass}" \
    -H "Content-Type: application/json" \
    -X POST "http://localhost:9200/_security/user/kibana_system/_password" \
    -d "{\"password\":\"${kibana_pass}\"}" >/dev/null
}

print_profile_info
ensure_ai_net
ensure_env_file
ensure_opencti_admin_email
ensure_opencti_admin_token
ensure_kibana_encryption_keys
ensure_logstash_files

echo "[2/9] Pre-pulling Docker images (sequential with retries)..."

OPENCTI_FILES=(
  "$ROOT_DIR/opencti/docker-compose.yml"
  "$ROOT_DIR/opencti/docker-compose.override.yml"
  "$ROOT_DIR/opencti/docker-compose.pins.yml"
  "$ROOT_DIR/opencti/docker-compose.exclude.yml"
)

MAIN_FILES=(
  "$ROOT_DIR/docker-compose.yml"
)

ALL_IMAGES="$(list_images_from_compose "${OPENCTI_FILES[@]}" "${MAIN_FILES[@]}")"

while IFS= read -r img; do
  [[ -z "${img//[[:space:]]/}" ]] && continue
  pull_with_retry "$img"
done <<< "$ALL_IMAGES"

echo "[3/9] Bringing up Elasticsearch first (so we can sync kibana_system creds before Kibana starts)..."
docker compose --env-file "$ENV_FILE" -f "$ROOT_DIR/docker-compose.yml" up -d elasticsearch

echo "[4/9] Waiting for Elasticsearch..."
wait_es_ok 240

echo "[4a] Verifying elastic superuser authentication..."
curl -fsS -u "elastic:$(get_env_value ELASTIC_PASSWORD)" \
  "http://localhost:9200/_security/_authenticate" >/dev/null \
  || {
    echo "ERROR: elastic superuser authentication failed. Check ELASTIC_PASSWORD." >&2
    exit 1
  }

# Ensure Kibana can auth BEFORE starting Kibana container
ensure_kibana_system_password

echo "[5/9] Bringing up the rest of the main stack (Kibana + Logstash + MCP + n8n + Ollama)..."
docker compose --env-file "$ENV_FILE" -f "$ROOT_DIR/docker-compose.yml" up -d

echo "[6/9] Bringing up OpenCTI (base + override + pins + exclude)..."
docker compose --env-file "$ENV_FILE" \
  -f "$ROOT_DIR/opencti/docker-compose.yml" \
  -f "$ROOT_DIR/opencti/docker-compose.override.yml" \
  -f "$ROOT_DIR/opencti/docker-compose.pins.yml" \
  -f "$ROOT_DIR/opencti/docker-compose.exclude.yml" \
  up -d

ensure_valid_elk_api_key

echo "[8/9] Kibana quick status..."
if curl -fsS "http://localhost:5601/api/status" >/dev/null 2>&1; then
  echo "  Kibana status endpoint reachable."
else
  echo "  Kibana status not reachable yet. Check logs: docker logs -f kibana"
fi

echo "[9/9] Done."
echo ""
echo "Services:"
echo "  ELK Elasticsearch: http://localhost:9200"
echo "  Kibana:            http://localhost:5601"
echo "  n8n:               http://localhost:5678"
echo "  Ollama:            http://localhost:11434"
echo "  OpenCTI:           http://localhost:8080"
