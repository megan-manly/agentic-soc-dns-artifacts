#!/bin/sh
set -eu

MODEL="${OLLAMA_MODEL:-llama3.1:8b-instruct-q4_K_M}"

echo "[ollama-seed] Pre-pulling model: $MODEL"

# Start daemon in background (so the pull has a local server)
ollama serve >/tmp/ollama.log 2>&1 &
pid=$!

# Wait a moment for server to start
sleep 2

# Pull the model into the shared volume
ollama pull "$MODEL"

# Stop background server
kill "$pid" || true
echo "[ollama-seed] Done."
